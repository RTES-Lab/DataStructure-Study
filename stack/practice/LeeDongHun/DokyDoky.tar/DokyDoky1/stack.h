#ifndef STACK_H
#define STACK_H

#include<stdio.h>
#include<stdlib.h>

typedef struct tagNode{
    int Order_Num;
    struct tagNode* NextNode;
}Node;

typedef struct{
    Node* Top;
    Node* List;
}Stack;

Node* CreateNode(int Order_Num);
Stack* CreateStack();
void PushStack(Stack* ArbStack, Node* AnyNode);
void PopStack(Stack* ArbStack);

#endif