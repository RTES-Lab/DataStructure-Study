#include "stack.h"

void main(){

    int ThisNum=1;  // 입장 가능한 번호
    int Num_People; // 대기줄 인원
    Stack* TmpStack=CreateStack(); // 임시 대기줄

    scanf(" %d",  &Num_People);
    int *array=(int*)malloc(sizeof(int)*Num_People);

    for(int i=0; i<Num_People; i++)    // 현재 대기줄 상황을 입력 받음
        scanf(" %d", &array[i]);
    
    for(int i=0; i<Num_People;){
        // 현재 대기줄의 맨 앞이 입장하는 경우,
        if(array[i]==ThisNum){
            array[i++]=0;
            ThisNum++;
        }
        // 임시 대기줄의 맨 앞이 입장하는 경우,
        else if(TmpStack->List!=NULL && TmpStack->List->Order_Num==ThisNum){
            PopStack(TmpStack);
            ThisNum++;
        }
        // 현재 대기줄의 맨 앞이 임시 대기줄로 이동하는 경우,
        else
            PushStack(TmpStack, CreateNode(array[i++]));
    }
    free(array);

    while(TmpStack->List!=NULL){
        // 임시 대기줄의 맨 앞이 입장 가능한 경우,
        if(TmpStack->List->Order_Num==ThisNum){
            PopStack(TmpStack);
            ThisNum++;
        }
        // 임시 대기줄의 맨 앞이 입장 불가능한 경우, 모두가 간식을 받을 수 없음.
        else{
            printf("Sad\n");
            free(TmpStack);
            return;
        }
    }
    printf("Nice\n");
    free(TmpStack);
}