#include "stack.h"

Node* CreateNode(int Order_Num){
    Node* NewNode=(Node*)malloc(sizeof(Node));
    NewNode->Order_Num=Order_Num;
    NewNode->NextNode=NULL;
    return NewNode;
}

Stack* CreateStack(){
    Stack* NewStack=(Stack*)malloc(sizeof(Stack));
    NewStack->List=NULL;
    return NewStack;
}

void PushStack(Stack* ArbStack, Node* AnyNode){ //헤드로 고치기
    if(ArbStack->List==NULL){
        ArbStack->List=AnyNode;
    }
    else{
        AnyNode->NextNode=ArbStack->List;
        ArbStack->List=AnyNode;
    }
}

void PopStack(Stack* ArbStack){
    Node* Head=ArbStack->List;
    ArbStack->List=Head->NextNode;
    free(Head);
}