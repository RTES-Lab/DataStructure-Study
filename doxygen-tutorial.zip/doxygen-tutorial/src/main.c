#include "util.h"

int main(void)
{
    double ans;
    vector *v1 = create_vector(1.5, 4);
    vector *v2 = create_vector(2.5, 4);

    ans = dot(v1, v2);

    printf("%lf\n", ans);
    
    delete_vector(v1);
    delete_vector(v2);


    return 0;
}
