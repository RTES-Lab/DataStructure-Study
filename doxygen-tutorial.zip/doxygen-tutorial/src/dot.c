#include "util.h"

/**
 @brief 두 벡터 간 내적을 계산한다.
자세한 설명이 더 있으면 아래에 계속 기술한다....
 @param[in] a 첫 번째 피연산자 벡터
 @param[in] b 두 번째 피연산자 벡터
 @return a와 b의 내적 결과값
 @warning 각 벡터의 길이는 모두 동일해야 함
 @pre \ref 각 벡터는 create_vector 함수로 초기화되어 있어야 함
 @todo 예외처리를 위해 함수 리팩토링
 @note 추가로 노트할 사항
 @bug 버그가 발생한 사항
 @par Example
 @code{.c}
 #include "util.h"
    double ans;
    vector *v1 = create_vector(1.5, 4); // [1.5, 1.5, 1.5, 1.5]
    vector *v2 = create_vector(2.5, 4); // [2.5, 2.5, 2.5, 2.5]
    ans = dot(v1, v2); // <- ans = 15.0
    printf("%lf\n", ans);
    delete_vector(v1);
    delete_vector(v2);
 @endcode
*/
double dot(vector *a, vector* b) {
    double ret = 0.0;

    int len = a->len;
    double *ad = a->data;
    double *bd = b->data;
    for(int i = 0; i < len; i++) {
        ret += ad[i] * bd[i];
    }

    return ret;
}