#include "util.h"

double dot(vector *a, vector* b) {
    double ret = 0.0;

    int len = a->len;
    double *ad = a->data;
    double *bd = b->data;
    for(int i = 0; i < len; i++) {
        ret += ad[i] * bd[i];
    }

    return ret;
}