#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/**
 @brief 1차원 벡터 구조체
1차원 배열을 표현하기 위한 데이터타입이다. 사용 이전
에 \ref create_vector
로 초기화를 수행해야 하며 사용이 다 끝나면 \ref
delete_vector 로 메모리를 반환해야 한다.
 @par Example
 @code{.c}
 #include "util.h"
 vector* v = create_vector(0.0, 3); // [0, 0, 0]
 for(int i = 0; i < v->len; i++) {
 v->data[i] = i + 1.0;
 }
// v = [1, 2, 3]
 delete_vector(v); // free memory
 @endcode
*/
typedef struct vector {
    double *data; /**< 데이터 포인터 \n
                    설명을 여러 줄로 \n
                    계속할 수 있다*/
    int len; /**< 벡터의 길이*/
} vector;

double dot(vector *a, vector* b);

vector* create_vector(double initial_value, int len);
void delete_vector(vector* v);
void print_vector(vector* v);
