#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct vector {
    double *data;
    int len;
} vector;

double dot(vector *a, vector* b);

vector* create_vector(double initial_value, int len);
void delete_vector(vector* v);
void print_vector(vector* v);
