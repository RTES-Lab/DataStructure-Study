#include "util.h"

vector* create_vector(double initial_value, int len) {
    vector* ret = (vector*)malloc(sizeof(vector));
    ret->data = (double*)malloc(sizeof(double)*len);
    ret->len = len;

    for(int i = 0; i < len; i++) {
        ret->data[i] = initial_value;
    }

    return ret;
}

void delete_vector(vector* v) {
    free(v->data);
    free(v);

    return;
}

void print_vector(vector* v) {
    int len = v->len;
    double *d = v->data;
    for(int i = 0; i < len; i++) {
        printf("%lf ", v->data[i]);
    }
    printf("\n");

    return;
}