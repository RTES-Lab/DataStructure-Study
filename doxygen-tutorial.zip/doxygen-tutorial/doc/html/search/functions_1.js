var searchData=
[
  ['delete_5fvector_0',['delete_vector',['../util_8h.html#a4d5a0a9dc7d691d68d34b45c759aa32a',1,'delete_vector(vector *v):&#160;vector.c'],['../vector_8c.html#a4d5a0a9dc7d691d68d34b45c759aa32a',1,'delete_vector(vector *v):&#160;vector.c']]],
  ['dot_1',['dot',['../dot_8c.html#a4b9d1b6612888fc272ac6d062ee81d10',1,'dot(vector *a, vector *b):&#160;dot.c'],['../util_8h.html#a4b9d1b6612888fc272ac6d062ee81d10',1,'dot(vector *a, vector *b):&#160;dot.c']]]
];
