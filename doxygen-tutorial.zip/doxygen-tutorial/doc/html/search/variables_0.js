var searchData=
[
  ['data_0',['data',['../structvector.html#a23436a7a2b44939627b59df11be7ad75',1,'vector']]]
];
