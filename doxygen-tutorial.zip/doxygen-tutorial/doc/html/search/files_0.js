var searchData=
[
  ['dot_2ec_0',['dot.c',['../dot_8c.html',1,'']]]
];
