var indexSectionsWithContent =
{
  0: "bcdlmptuv메목상제페하",
  1: "v",
  2: "dmuv",
  3: "cdmp",
  4: "dl",
  5: "v",
  6: "blt메제페"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Pages"
};

