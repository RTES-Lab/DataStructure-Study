var searchData=
[
  ['create_5fvector_0',['create_vector',['../util_8h.html#a207c201aa72249b76cfed13e1674784c',1,'create_vector(double initial_value, int len):&#160;vector.c'],['../vector_8c.html#a207c201aa72249b76cfed13e1674784c',1,'create_vector(double initial_value, int len):&#160;vector.c']]]
];
