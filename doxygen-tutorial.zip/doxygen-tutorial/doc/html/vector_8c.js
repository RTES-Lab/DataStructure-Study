var vector_8c =
[
    [ "create_vector", "vector_8c.html#a207c201aa72249b76cfed13e1674784c", null ],
    [ "delete_vector", "vector_8c.html#a4d5a0a9dc7d691d68d34b45c759aa32a", null ],
    [ "print_vector", "vector_8c.html#ac7de4671c12d729aa1aba44d999847a1", null ]
];