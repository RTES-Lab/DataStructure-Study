var group___functions =
[
    [ "ResponseKeyDown", "group___functions.html#ga1b8817382ef71218b5c24982e9320b8a", null ],
    [ "ResponseKeyUp", "group___functions.html#ga760f3d944fc0e0a2c9636d785cd07ca8", null ]
];