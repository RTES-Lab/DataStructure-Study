var draw_8h =
[
    [ "ClearWindow", "group___draw.html#ga07863ec93360df2f9a1b5eff97890563", null ],
    [ "DrawGame", "group___draw.html#gab33f4146ab23c4be91566a68e68895fe", null ],
    [ "DrawGameOver", "group___draw.html#ga52d7bd7319e47472de78cdbf95856b88", null ],
    [ "RenderEntity", "group___draw.html#ga303fcf31d5f32fbaa70040fa5848ff04", null ],
    [ "RenderScoreBoard", "group___draw.html#ga0e4dc5510d16de6f635e3229e999bddc", null ],
    [ "ShowWindow", "group___draw.html#ga17ef8abf91a443ec16525f4d95d7836e", null ],
    [ "app", "group___global_variables.html#ga05b5a24325d46227633053ca49de6234", null ],
    [ "bullet", "group___global_variables.html#ga3969fcbadddf924ee352d7e232919bf5", null ],
    [ "game_over", "group___global_variables.html#ga30f03aaf13c260e57b759c650c99468e", null ],
    [ "player", "group___global_variables.html#gaa98761129f4d5e69468dcbdddbd88d9d", null ],
    [ "score", "group___global_variables.html#gaef160b7437d94056f1dc59646cd5b87d", null ],
    [ "score_board", "group___global_variables.html#gafef3fdea043a22bb19f93f3799421010", null ],
    [ "score_text", "group___global_variables.html#gae3c21975ce19d3b28f11d50419e15ab9", null ]
];