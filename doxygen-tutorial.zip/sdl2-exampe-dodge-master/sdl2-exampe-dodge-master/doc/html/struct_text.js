var struct_text =
[
    [ "color", "struct_text.html#a631bf4babe4c1825a2cdc0c19c2bd04f", null ],
    [ "pos", "struct_text.html#a294c5492db3ece725b68947cafdaafec", null ],
    [ "surface", "struct_text.html#a2f5cac12e913bcfcff660305bf88dd3b", null ],
    [ "texture", "struct_text.html#a859b8efbf9abe8e82757ee5c75a0c97c", null ]
];