var group___draw =
[
    [ "ClearWindow", "group___draw.html#ga07863ec93360df2f9a1b5eff97890563", null ],
    [ "DrawGame", "group___draw.html#gab33f4146ab23c4be91566a68e68895fe", null ],
    [ "DrawGameOver", "group___draw.html#ga52d7bd7319e47472de78cdbf95856b88", null ],
    [ "RenderEntity", "group___draw.html#ga303fcf31d5f32fbaa70040fa5848ff04", null ],
    [ "RenderScoreBoard", "group___draw.html#ga0e4dc5510d16de6f635e3229e999bddc", null ],
    [ "ShowWindow", "group___draw.html#ga17ef8abf91a443ec16525f4d95d7836e", null ]
];