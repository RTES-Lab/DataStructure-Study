var defs_8h =
[
    [ "App", "struct_app.html", "struct_app" ],
    [ "Entity", "struct_entity.html", "struct_entity" ],
    [ "Text", "struct_text.html", "struct_text" ],
    [ "BOTTOM_WALL", "defs_8h.html#a6feda6df1811c85b4c25d2fa8c8a852d", null ],
    [ "BUFSIZE", "defs_8h.html#aeca034f67218340ecb2261a22c2f3dcd", null ],
    [ "BULLET_HEIGHT", "defs_8h.html#ac91cd0386a836b604804b5dd09c0a65c", null ],
    [ "BULLET_SPEED", "defs_8h.html#a70b3e643b533b8f785b7912e69434161", null ],
    [ "BULLET_WIDTH", "defs_8h.html#ad135231941b972722b6ef5f5bd0670d2", null ],
    [ "FONTSIZE", "defs_8h.html#a5d52eeb41a03aeda6974d60772531f96", null ],
    [ "FPS", "defs_8h.html#ac92ca5ab87034a348decad7ee8d4bd1b", null ],
    [ "LEFT_WALL", "defs_8h.html#a116554c107df8fc01a4ba0b69bb1171f", null ],
    [ "NUM_BULLETS", "defs_8h.html#ac2f0ab514de41108a223c4edd49a6dfb", null ],
    [ "PLAYER_HEIGHT", "defs_8h.html#a2712b06fd52f25adca031d05c3e0c09b", null ],
    [ "PLAYER_SPEED", "defs_8h.html#af49bad41acef45feb40939c0cf9d5d35", null ],
    [ "PLAYER_WIDTH", "defs_8h.html#a89e2ac9092225702ac543695d0771d38", null ],
    [ "RIGHT_WALL", "defs_8h.html#a7a9ff4af55a52a1d25d42a61253307f6", null ],
    [ "SCREEN_HEIGHT", "defs_8h.html#a6974d08a74da681b3957b2fead2608b8", null ],
    [ "SCREEN_WIDTH", "defs_8h.html#a2cd109632a6dcccaa80b43561b1ab700", null ],
    [ "TOP_WALL", "defs_8h.html#a61987d8469391b3cd6ecff047cfb05e7", null ]
];