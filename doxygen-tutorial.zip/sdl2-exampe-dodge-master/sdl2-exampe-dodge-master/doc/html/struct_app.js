var struct_app =
[
    [ "font", "struct_app.html#abf5bfa705e66ffc1ddaa6ce46c960873", null ],
    [ "key_down", "struct_app.html#a98550f2222a6d450fc03453bf71b8991", null ],
    [ "key_left", "struct_app.html#ac10cd65003a356e086d2c9ca76b1a9d1", null ],
    [ "key_r", "struct_app.html#aceb96cadd2804e1589e11192886e0043", null ],
    [ "key_right", "struct_app.html#af929151dd14c88998cfe0eb78d0dc0a3", null ],
    [ "key_up", "struct_app.html#a1c650232521010da69bb82f93ebcd495", null ],
    [ "renderer", "struct_app.html#a966da7a60c4ea3ba301e26ccc5efe452", null ],
    [ "window", "struct_app.html#aaa8e409e04dcf575ef63fd5fb3db06f9", null ]
];