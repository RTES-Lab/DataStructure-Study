var files =
[
    [ "action.c", "action_8c.html", "action_8c" ],
    [ "action.h", "action_8h.html", "action_8h" ],
    [ "defs.h", "defs_8h.html", "defs_8h" ],
    [ "draw.c", "draw_8c.html", "draw_8c" ],
    [ "draw.h", "draw_8h.html", "draw_8h" ],
    [ "init.c", "init_8c.html", "init_8c" ],
    [ "init.h", "init_8h.html", "init_8h" ],
    [ "input.c", "input_8c.html", "input_8c" ],
    [ "input.h", "input_8h.html", "input_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "main.h", "main_8h.html", "main_8h" ],
    [ "sound.h", "sound_8h.html", "sound_8h" ],
    [ "utils.c", "utils_8c.html", "utils_8c" ],
    [ "utils.h", "utils_8h.html", "utils_8h" ]
];