var utils_8h =
[
    [ "CheckCollisionObjects", "group___utils.html#gad09f6116d9d2c9a447bff3c40b69d29a", null ],
    [ "CheckCollisionSide", "group___utils.html#ga108e3df81f9bc0ce2ddcfae182544d7a", null ],
    [ "CheckCollisionWall", "group___utils.html#ga53db3177844e1195be84da6b045d19cb", null ],
    [ "RandDouble", "group___utils.html#ga87d33d8b54bca3955ef58a77d52995eb", null ],
    [ "RandInt", "group___utils.html#gaff4ea7a61b3342b59e917bcc7dd08500", null ],
    [ "RandSpawnBullet", "group___utils.html#ga5cb63b050f48798afe28117861e98271", null ],
    [ "app", "group___global_variables.html#ga05b5a24325d46227633053ca49de6234", null ],
    [ "bullet", "group___global_variables.html#ga3969fcbadddf924ee352d7e232919bf5", null ],
    [ "game_over", "group___global_variables.html#ga30f03aaf13c260e57b759c650c99468e", null ],
    [ "player", "group___global_variables.html#gaa98761129f4d5e69468dcbdddbd88d9d", null ],
    [ "score", "group___global_variables.html#gaef160b7437d94056f1dc59646cd5b87d", null ],
    [ "score_board", "group___global_variables.html#gafef3fdea043a22bb19f93f3799421010", null ],
    [ "score_text", "group___global_variables.html#gae3c21975ce19d3b28f11d50419e15ab9", null ]
];