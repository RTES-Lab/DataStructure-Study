var init_8c =
[
    [ "InitBullet", "group___init.html#ga30c1a22616a4bc3d87ab7197913e62d6", null ],
    [ "InitGameOver", "group___init.html#gac20fccf3f37ac898a607e7ca2aae7081", null ],
    [ "InitMemorySet", "group___init.html#ga0a26d5779d3a2a2c898c3f52b74ddf3a", null ],
    [ "InitPlayer", "group___init.html#ga068fc32638e272bb7c61516d6efe4b9e", null ],
    [ "InitScoreBoard", "group___init.html#gab233da79a00de5b6a0752c031b1f9855", null ],
    [ "InitSDL", "group___init.html#ga427bf0e70445f92f07adb6512985699d", null ],
    [ "InitTTF", "group___init.html#ga82fb88870e950b4d0b484e2744d6b064", null ],
    [ "QuitSDL", "group___init.html#gaa2128129f94d9519cfc62de7e308bac7", null ],
    [ "QuitTTF", "group___init.html#ga6ba0c53f3cc9980ebe30a2286632bb45", null ]
];