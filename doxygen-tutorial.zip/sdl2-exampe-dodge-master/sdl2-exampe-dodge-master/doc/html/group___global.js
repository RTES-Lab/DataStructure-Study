var group___global =
[
    [ "app", "group___global.html#ga05b5a24325d46227633053ca49de6234", null ],
    [ "bullet", "group___global.html#ga3969fcbadddf924ee352d7e232919bf5", null ],
    [ "game_over", "group___global.html#ga30f03aaf13c260e57b759c650c99468e", null ],
    [ "player", "group___global.html#gaa98761129f4d5e69468dcbdddbd88d9d", null ],
    [ "score", "group___global.html#gaef160b7437d94056f1dc59646cd5b87d", null ],
    [ "score_board", "group___global.html#gafef3fdea043a22bb19f93f3799421010", null ],
    [ "score_text", "group___global.html#gae3c21975ce19d3b28f11d50419e15ab9", null ]
];