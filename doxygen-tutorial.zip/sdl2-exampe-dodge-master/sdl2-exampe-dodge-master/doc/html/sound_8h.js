var sound_8h =
[
    [ "InitSound", "group___sound.html#ga7653c9d91bc20ef678286370a50c0114", null ],
    [ "LoadSound", "group___sound.html#gafaedd84d273ad036eb5b2bbfbafd660a", null ],
    [ "PlayBGM", "group___sound.html#gaef6dd183c3d30d35e6426e1c9880f926", null ],
    [ "PlayDeathEffect", "group___sound.html#gab4bccf4f5d3f348d040eb1bc97dbc910", null ],
    [ "bgm", "group___global_variables.html#ga015eb04e0a2b9b43b073ff5abf39a6ea", null ],
    [ "death_effect", "group___global_variables.html#ga30ae93fe5207caf41fb5d96ca640a564", null ]
];