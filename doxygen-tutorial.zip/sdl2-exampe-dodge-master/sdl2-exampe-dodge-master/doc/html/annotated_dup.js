var annotated_dup =
[
    [ "App", "struct_app.html", "struct_app" ],
    [ "Entity", "struct_entity.html", "struct_entity" ],
    [ "Text", "struct_text.html", "struct_text" ]
];