var modules =
[
    [ "GlobalVariables", "group___global_variables.html", "group___global_variables" ],
    [ "Init", "group___init.html", "group___init" ],
    [ "Input", "group___input.html", "group___input" ],
    [ "Action", "group___action.html", "group___action" ],
    [ "Draw", "group___draw.html", "group___draw" ],
    [ "Utils", "group___utils.html", "group___utils" ],
    [ "Sound", "group___sound.html", "group___sound" ]
];