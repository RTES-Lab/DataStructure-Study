var searchData=
[
  ['player_5fheight',['PLAYER_HEIGHT',['../defs_8h.html#a2712b06fd52f25adca031d05c3e0c09b',1,'defs.h']]],
  ['player_5fspeed',['PLAYER_SPEED',['../defs_8h.html#af49bad41acef45feb40939c0cf9d5d35',1,'defs.h']]],
  ['player_5fwidth',['PLAYER_WIDTH',['../defs_8h.html#a89e2ac9092225702ac543695d0771d38',1,'defs.h']]]
];
