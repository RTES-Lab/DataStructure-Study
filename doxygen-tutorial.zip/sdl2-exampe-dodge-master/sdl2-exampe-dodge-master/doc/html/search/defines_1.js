var searchData=
[
  ['fontsize',['FONTSIZE',['../defs_8h.html#a5d52eeb41a03aeda6974d60772531f96',1,'defs.h']]],
  ['fps',['FPS',['../defs_8h.html#ac92ca5ab87034a348decad7ee8d4bd1b',1,'defs.h']]]
];
