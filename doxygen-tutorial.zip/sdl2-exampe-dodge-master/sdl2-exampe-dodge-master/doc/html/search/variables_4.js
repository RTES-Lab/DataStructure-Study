var searchData=
[
  ['font',['font',['../struct_app.html#abf5bfa705e66ffc1ddaa6ce46c960873',1,'App']]]
];
