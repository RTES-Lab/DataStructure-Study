var searchData=
[
  ['text',['Text',['../struct_text.html',1,'']]]
];
