var searchData=
[
  ['randdouble',['RandDouble',['../group___utils.html#ga87d33d8b54bca3955ef58a77d52995eb',1,'RandDouble(double min_val, double max_val):&#160;utils.c'],['../group___utils.html#ga87d33d8b54bca3955ef58a77d52995eb',1,'RandDouble(double min_val, double max_val):&#160;utils.c']]],
  ['randint',['RandInt',['../group___utils.html#gaff4ea7a61b3342b59e917bcc7dd08500',1,'RandInt(int min_val, int max_val):&#160;utils.c'],['../group___utils.html#gaff4ea7a61b3342b59e917bcc7dd08500',1,'RandInt(int min_val, int max_val):&#160;utils.c']]],
  ['randspawnbullet',['RandSpawnBullet',['../group___utils.html#ga5cb63b050f48798afe28117861e98271',1,'RandSpawnBullet(Entity *object):&#160;utils.c'],['../group___utils.html#ga5cb63b050f48798afe28117861e98271',1,'RandSpawnBullet(Entity *object):&#160;utils.c']]],
  ['renderentity',['RenderEntity',['../group___draw.html#ga303fcf31d5f32fbaa70040fa5848ff04',1,'RenderEntity(Entity *object):&#160;draw.c'],['../group___draw.html#ga303fcf31d5f32fbaa70040fa5848ff04',1,'RenderEntity(Entity *object):&#160;draw.c']]],
  ['renderscoreboard',['RenderScoreBoard',['../group___draw.html#ga0e4dc5510d16de6f635e3229e999bddc',1,'RenderScoreBoard(Text *object):&#160;draw.c'],['../group___draw.html#ga0e4dc5510d16de6f635e3229e999bddc',1,'RenderScoreBoard(Text *object):&#160;draw.c']]],
  ['responsekeydown',['ResponseKeyDown',['../group___input.html#ga1b8817382ef71218b5c24982e9320b8a',1,'ResponseKeyDown(SDL_KeyboardEvent *event):&#160;input.c'],['../group___input.html#ga1b8817382ef71218b5c24982e9320b8a',1,'ResponseKeyDown(SDL_KeyboardEvent *event):&#160;input.c']]],
  ['responsekeyup',['ResponseKeyUp',['../group___input.html#ga760f3d944fc0e0a2c9636d785cd07ca8',1,'ResponseKeyUp(SDL_KeyboardEvent *event):&#160;input.c'],['../group___input.html#ga760f3d944fc0e0a2c9636d785cd07ca8',1,'ResponseKeyUp(SDL_KeyboardEvent *event):&#160;input.c']]]
];
