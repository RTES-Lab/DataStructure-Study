var searchData=
[
  ['checkcollisionobjects',['CheckCollisionObjects',['../group___utils.html#gad09f6116d9d2c9a447bff3c40b69d29a',1,'CheckCollisionObjects(Entity *object_a, Entity *object_b):&#160;utils.c'],['../group___utils.html#gad09f6116d9d2c9a447bff3c40b69d29a',1,'CheckCollisionObjects(Entity *object_a, Entity *object_b):&#160;utils.c']]],
  ['checkcollisionside',['CheckCollisionSide',['../group___utils.html#ga108e3df81f9bc0ce2ddcfae182544d7a',1,'CheckCollisionSide(Entity *object):&#160;utils.c'],['../group___utils.html#ga108e3df81f9bc0ce2ddcfae182544d7a',1,'CheckCollisionSide(Entity *object):&#160;utils.c']]],
  ['checkcollisionwall',['CheckCollisionWall',['../group___utils.html#ga53db3177844e1195be84da6b045d19cb',1,'CheckCollisionWall(Entity *object):&#160;utils.c'],['../group___utils.html#ga53db3177844e1195be84da6b045d19cb',1,'CheckCollisionWall(Entity *object):&#160;utils.c']]],
  ['clearwindow',['ClearWindow',['../group___draw.html#ga07863ec93360df2f9a1b5eff97890563',1,'ClearWindow(void):&#160;draw.c'],['../group___draw.html#ga07863ec93360df2f9a1b5eff97890563',1,'ClearWindow(void):&#160;draw.c']]],
  ['color',['color',['../struct_text.html#a631bf4babe4c1825a2cdc0c19c2bd04f',1,'Text']]]
];
