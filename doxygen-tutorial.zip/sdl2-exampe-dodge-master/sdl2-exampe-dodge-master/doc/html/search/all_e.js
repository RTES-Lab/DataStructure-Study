var searchData=
[
  ['quitsdl',['QuitSDL',['../group___init.html#gaa2128129f94d9519cfc62de7e308bac7',1,'QuitSDL(int flag):&#160;init.c'],['../group___init.html#gaa2128129f94d9519cfc62de7e308bac7',1,'QuitSDL(int flag):&#160;init.c']]],
  ['quitttf',['QuitTTF',['../group___init.html#ga6ba0c53f3cc9980ebe30a2286632bb45',1,'QuitTTF(void):&#160;init.c'],['../group___init.html#ga6ba0c53f3cc9980ebe30a2286632bb45',1,'QuitTTF(void):&#160;init.c']]]
];
