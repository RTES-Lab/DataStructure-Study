var indexSectionsWithContent =
{
  0: "abcdefghiklmnpqrstuvw",
  1: "aet",
  2: "adimsu",
  3: "acdgilpqrs",
  4: "abcdfghkprstvw",
  5: "bflnprst",
  6: "adgisu",
  7: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Modules",
  7: "Pages"
};

