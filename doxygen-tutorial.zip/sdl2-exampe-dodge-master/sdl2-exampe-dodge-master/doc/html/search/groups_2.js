var searchData=
[
  ['globalvariables',['GlobalVariables',['../group___global_variables.html',1,'']]]
];
