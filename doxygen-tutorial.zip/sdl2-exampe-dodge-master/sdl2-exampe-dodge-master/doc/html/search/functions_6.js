var searchData=
[
  ['playbgm',['PlayBGM',['../group___sound.html#gaef6dd183c3d30d35e6426e1c9880f926',1,'PlayBGM(void):&#160;sound.c'],['../group___sound.html#gaef6dd183c3d30d35e6426e1c9880f926',1,'PlayBGM(void):&#160;sound.c']]],
  ['playdeatheffect',['PlayDeathEffect',['../group___sound.html#gab4bccf4f5d3f348d040eb1bc97dbc910',1,'PlayDeathEffect(void):&#160;sound.c'],['../group___sound.html#gab4bccf4f5d3f348d040eb1bc97dbc910',1,'PlayDeathEffect(void):&#160;sound.c']]]
];
