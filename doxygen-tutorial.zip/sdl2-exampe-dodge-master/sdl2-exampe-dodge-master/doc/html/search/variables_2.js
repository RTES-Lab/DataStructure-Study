var searchData=
[
  ['color',['color',['../struct_text.html#a631bf4babe4c1825a2cdc0c19c2bd04f',1,'Text']]]
];
