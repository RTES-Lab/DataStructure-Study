var searchData=
[
  ['num_5fbullets',['NUM_BULLETS',['../defs_8h.html#ac2f0ab514de41108a223c4edd49a6dfb',1,'defs.h']]]
];
