var searchData=
[
  ['loadsound',['LoadSound',['../group___sound.html#gafaedd84d273ad036eb5b2bbfbafd660a',1,'LoadSound(void):&#160;sound.c'],['../group___sound.html#gafaedd84d273ad036eb5b2bbfbafd660a',1,'LoadSound(void):&#160;sound.c']]]
];
