var searchData=
[
  ['death_5feffect',['death_effect',['../group___global_variables.html#ga30ae93fe5207caf41fb5d96ca640a564',1,'death_effect():&#160;main.h'],['../group___global_variables.html#ga30ae93fe5207caf41fb5d96ca640a564',1,'death_effect():&#160;main.h']]]
];
