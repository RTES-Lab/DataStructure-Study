var searchData=
[
  ['texture',['texture',['../struct_entity.html#a859b8efbf9abe8e82757ee5c75a0c97c',1,'Entity::texture()'],['../struct_text.html#a859b8efbf9abe8e82757ee5c75a0c97c',1,'Text::texture()']]],
  ['theta',['theta',['../struct_entity.html#aca81c35c21e3a5f7f3a8d24504e76664',1,'Entity']]]
];
