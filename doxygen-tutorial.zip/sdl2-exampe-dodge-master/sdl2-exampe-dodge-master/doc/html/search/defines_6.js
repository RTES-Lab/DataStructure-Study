var searchData=
[
  ['screen_5fheight',['SCREEN_HEIGHT',['../defs_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'defs.h']]],
  ['screen_5fwidth',['SCREEN_WIDTH',['../defs_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'defs.h']]]
];
