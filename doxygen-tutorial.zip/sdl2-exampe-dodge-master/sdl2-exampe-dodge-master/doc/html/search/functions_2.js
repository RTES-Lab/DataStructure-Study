var searchData=
[
  ['drawgame',['DrawGame',['../group___draw.html#gab33f4146ab23c4be91566a68e68895fe',1,'DrawGame(void):&#160;draw.c'],['../group___draw.html#gab33f4146ab23c4be91566a68e68895fe',1,'DrawGame(void):&#160;draw.c']]],
  ['drawgameover',['DrawGameOver',['../group___draw.html#ga52d7bd7319e47472de78cdbf95856b88',1,'DrawGameOver(void):&#160;draw.c'],['../group___draw.html#ga52d7bd7319e47472de78cdbf95856b88',1,'DrawGameOver(void):&#160;draw.c']]]
];
