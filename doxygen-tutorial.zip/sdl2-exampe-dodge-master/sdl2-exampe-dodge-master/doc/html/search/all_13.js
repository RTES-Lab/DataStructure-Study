var searchData=
[
  ['v_5fx',['v_x',['../struct_entity.html#af8ea4d2851d2d656fd42be239e36ce6e',1,'Entity']]],
  ['v_5fy',['v_y',['../struct_entity.html#a2161079bbf87834cfdf4d3548a53eb3b',1,'Entity']]]
];
