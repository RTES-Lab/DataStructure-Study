var action_8h =
[
    [ "ActBullet", "group___action.html#ga94b64a686b9deac756fc84a1f21d182a", null ],
    [ "ActCheckDeath", "group___action.html#ga95ce7534309c25f41e7f6c95a84526fe", null ],
    [ "ActFinalScoreBoard", "group___action.html#gaa65db23b8a8d08fdab84f41d2d77fc16", null ],
    [ "ActGame", "group___action.html#ga8bcfa253c4b96ef478fd200900a30eac", null ],
    [ "ActGameOver", "group___action.html#ga981d44fa9ea88e54c20d6a74c037277d", null ],
    [ "ActGameOverScreen", "group___action.html#ga7dabaf213b8ac9a73d5312d2b4c219a3", null ],
    [ "ActPlayer", "group___action.html#gad1c341bd8d66cfa6307f9eda7fcb517f", null ],
    [ "ActScoreBoard", "group___action.html#ga7d7e08b4f43179e1c112660ebf499f38", null ],
    [ "app", "group___global_variables.html#ga05b5a24325d46227633053ca49de6234", null ],
    [ "bullet", "group___global_variables.html#ga3969fcbadddf924ee352d7e232919bf5", null ],
    [ "game_over", "group___global_variables.html#ga30f03aaf13c260e57b759c650c99468e", null ],
    [ "player", "group___global_variables.html#gaa98761129f4d5e69468dcbdddbd88d9d", null ],
    [ "score", "group___global_variables.html#gaef160b7437d94056f1dc59646cd5b87d", null ],
    [ "score_board", "group___global_variables.html#gafef3fdea043a22bb19f93f3799421010", null ],
    [ "score_text", "group___global_variables.html#gae3c21975ce19d3b28f11d50419e15ab9", null ]
];