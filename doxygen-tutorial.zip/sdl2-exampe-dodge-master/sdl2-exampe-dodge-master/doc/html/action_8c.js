var action_8c =
[
    [ "ActBullet", "group___action.html#ga94b64a686b9deac756fc84a1f21d182a", null ],
    [ "ActCheckDeath", "group___action.html#ga95ce7534309c25f41e7f6c95a84526fe", null ],
    [ "ActFinalScoreBoard", "group___action.html#gaa65db23b8a8d08fdab84f41d2d77fc16", null ],
    [ "ActGame", "group___action.html#ga8bcfa253c4b96ef478fd200900a30eac", null ],
    [ "ActGameOver", "group___action.html#ga981d44fa9ea88e54c20d6a74c037277d", null ],
    [ "ActGameOverScreen", "group___action.html#ga7dabaf213b8ac9a73d5312d2b4c219a3", null ],
    [ "ActPlayer", "group___action.html#gad1c341bd8d66cfa6307f9eda7fcb517f", null ],
    [ "ActScoreBoard", "group___action.html#ga7d7e08b4f43179e1c112660ebf499f38", null ]
];