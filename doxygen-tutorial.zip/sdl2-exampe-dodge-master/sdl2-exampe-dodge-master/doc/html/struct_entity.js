var struct_entity =
[
    [ "health", "struct_entity.html#ae448fb16f537982185a0c5e8db56bdc6", null ],
    [ "pos", "struct_entity.html#a294c5492db3ece725b68947cafdaafec", null ],
    [ "texture", "struct_entity.html#a859b8efbf9abe8e82757ee5c75a0c97c", null ],
    [ "theta", "struct_entity.html#aca81c35c21e3a5f7f3a8d24504e76664", null ],
    [ "v_x", "struct_entity.html#af8ea4d2851d2d656fd42be239e36ce6e", null ],
    [ "v_y", "struct_entity.html#a2161079bbf87834cfdf4d3548a53eb3b", null ]
];