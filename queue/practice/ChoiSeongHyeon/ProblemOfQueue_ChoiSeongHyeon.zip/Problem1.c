#include "LinkedQueue.h"

int main(void)
{
    int NumberOfCard;

    //제거 연산 후 다시 노드를 삽입하기 위한 변수
    LinkedQueue * Queue;
    Node * Popped;

    printf("카드 장수를 입력하시오 : ");
    scanf("%d", &NumberOfCard);
    printf("\n"); 

    //여기서부터 문제 해결
    LQ_CreateQueue(&Queue);

    for(int i = 0; i < NumberOfCard; i++)
    {
        LQ_Enqueue(Queue, LQ_CreateNode(i+1));
    }

    while(Queue->Count != 1)
    {
        //제거 연산 진행 - > 완전히 노드도 없애야 함!
        Popped = LQ_Dequeue(Queue);
        LQ_DestroyNode(Popped);

        Popped = LQ_Dequeue(Queue);
        LQ_Enqueue(Queue,LQ_CreateNode(Popped->Data));
        LQ_DestroyNode(Popped);

    }

    printf("마지막 카드의 숫자는 %d입니다.", Queue->Front->Data);
    Popped = LQ_Dequeue(Queue);
    LQ_DestroyNode(Popped);
    LQ_DestroyQueue(Queue);

    return 0;
}