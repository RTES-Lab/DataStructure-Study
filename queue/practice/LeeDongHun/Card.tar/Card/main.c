#include "Queue.h"

int main(){
    Queue* Cards=CreateQueue();
    int CntCard;

    scanf(" %d", &CntCard);
    for(int i=1; i<=CntCard; i++){  // CntCard개의 카드를 생성
        InQueue(Cards, CreateNode(i));
    }

    int i=0;
    while(Cards->Front!=Cards->Rear){ // 카드가 한장만 남을 때까지 반복
        switch(i%2){
            case 0: // 카드 삭제
                DeQueue(Cards);
                break;
            case 1: // 카드 순환
                Circulation(Cards);
                break;
            default:
                break;
        }
        i++;
    }
    
    printf("마지막 남은 카드 : %d\n", Cards->Front->NumCard);

    free(Cards->Front);
    free(Cards);
}