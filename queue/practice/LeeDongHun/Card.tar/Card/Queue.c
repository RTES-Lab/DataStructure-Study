#include "Queue.h"

Node* CreateNode(int NumCard){
    Node* NewNode=(Node*)malloc(sizeof(Node));
    NewNode->NextNode=NULL;
    NewNode->NumCard=NumCard;
    return NewNode;
}

Queue* CreateQueue(){
    Queue* NewQueue=(Queue*)malloc(sizeof(Queue*));
    NewQueue->Rear=NewQueue->Front=NULL;
    return NewQueue;
}

void InQueue(Queue* ArbQueue, Node* AnyNode){
    if(ArbQueue->Front==NULL){
        ArbQueue->Front=ArbQueue->Rear=AnyNode;
    }
    else{
        ArbQueue->Rear->NextNode=AnyNode;
        ArbQueue->Rear=ArbQueue->Rear->NextNode;
    }
}

void DeQueue(Queue* ArbQueue){
    Node* Remove=ArbQueue->Front;
    ArbQueue->Front=Remove->NextNode;
    free(Remove);
}

void Circulation(Queue* ArbQueue){
    //Front 변경
    Node* QueueFront=ArbQueue->Front;
    ArbQueue->Front=QueueFront->NextNode;
    //Rear 변경
    ArbQueue->Rear->NextNode=QueueFront;
    ArbQueue->Rear=ArbQueue->Rear->NextNode;
}