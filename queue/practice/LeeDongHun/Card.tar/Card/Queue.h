#ifndef Queue_H
#define Queue_H

#include<stdio.h>
#include<stdlib.h>

typedef struct tagNode{
    int NumCard;
    struct tagNode* NextNode;
}Node;


typedef struct tagQueue{
    Node* Rear;
    Node* Front;
}Queue;

/**
 * @brief 카드를 생성시키는 함수
 * @param NumCard 생성되는 카드 번호
*/
Node* CreateNode(int NumCard);

Queue* CreateQueue();

void InQueue(Queue* ArbQueue, Node* AnyNode);

void DeQueue(Queue* ArbQueue);
/**
 * @brief 맨 위의 카드를 맨 아래로 이동시키는 함수
 * @param ArbQueue 임의의 큐
*/
void Circulation(Queue* ArbQueue);
#endif