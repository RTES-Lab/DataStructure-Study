#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define lenName 31

/**
 * @struct Node
 * @brief 명령어를 모아놓은 enum
*/
enum Command { Down=-1, InsTag, InsNode, Show};


/**
 * @struct Node
 * @brief 노드 생성을 위한 구조체
*/
typedef struct tagNode{
    char *NodeName;                 /**<현재 노드의 이름*/
    struct tagNode *NextNode;       /**<다음 노드의 주소*/
}Node;

/**
 * @struct Tag
 * @brief 태그 생성을 위한 구조체
*/
typedef struct tagCategory{
    char *TagName;                      /**<현재 태그의 이름*/
    Node *NextNode;                     /**<현재 태그의 속한 헤드의 주소*/
    struct tagCategory *NextTag;        /**<다음 태그 주소*/
}Tag;

Node* CreateNode(char *Name);

Tag* CreateTag(char *NewTagName);

void InsertTag(Tag** tag, char* NewTagName);

void InsertNode(Tag** tag, char* NowTagName, char* NewNodeName);

/**
 * @brief 태그 검색
 * @param tag 태그 이름
 * @param NewNode 새롭게 생성한 노드 이름
*/
Tag* SearchTag(Tag *tag, char* TheTagName);

/**
 * @brief 태그와 노드 출력
 * @param tag 태그 이름
 * @param NewNode 새롭게 생성한 노드 이름
*/
void PrintList(Tag *tag);