#include "List.h"

// 입력: 커맨드 카테고리 파일

void main() {
    Tag *tag=NULL;
    Tag *NowTag=NULL;
    enum Command Cmd;

    char line[70];
    char *CmdLine = (char*)malloc(sizeof(char[5]));
    char *TagName = (char*)malloc(sizeof(char[lenName]));
    char *NodeName = (char*)malloc(sizeof(char[lenName]));

    for(;;){
        fgets(line, 70, stdin);
        CmdLine=strtok(line, "/");

        switch(atoi(CmdLine)){
            case Down:
                return;

            case InsTag:
                InsertTag(&tag, strtok(NULL, "/\n"));
                break;

            case InsNode:
                InsertNode(&tag, strtok(NULL, "/"), strtok(NULL, "/\n"));
                break;

            case Show:
                PrintList(tag);
                break;
            default:
                printf("지원하지 않는 명령어입니다.\n");
        }
    }
}