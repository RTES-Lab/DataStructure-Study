#include "List.h"

Node* CreateNode(char* Name){
    int i=0;    //노드이름 글자수
    Node *NewNode=(Node*)malloc(sizeof(Node));
    NewNode->NodeName=(char*)malloc(sizeof(char[lenName]));
    while(Name[i]!='\0'){    //노드이름 글자수 세기 (수정)
        NewNode->NodeName[i]=Name[i];
        i++;
    }
    Name[i]='\0';
    NewNode->NextNode=NULL;
    return NewNode;
}

Tag* CreateTag(char* NewTagName){
    int i=0;    //노드이름 글자수
    Tag* NewTag=(Tag*)malloc(sizeof(Tag));
    NewTag->TagName=(char*)malloc(sizeof(char[lenName]));
    while(NewTagName[i]!='\0'){    // 노드이름 글자수 세기 (수정)
        NewTag->TagName[i]=NewTagName[i];
        i++;
    }
    NewTag->TagName[i]='\0';
    NewTag->NextNode=NULL;
    NewTag->NextTag=NULL;
    return NewTag;
}

Tag* SearchTag(Tag *tag, char* TheTagName){
    Tag *Current=tag;

    while(Current!=NULL && strcmp(Current->TagName, TheTagName)<0){
        Current=Current->NextTag;
    }

    if(Current==NULL || strcmp(Current->TagName, TheTagName)!=0)
        return NULL;    // 찾는 카테고리가 없는 경우,
    
    return Current;     // 찾는 카테고리가 있는 경우,
}

void InsertTag(Tag** tag, char* NewTagName){

    Tag* NewTag;
    int D=-1;

    if((*tag)==NULL || (D=strcmp( NewTagName, (*tag)->TagName))<=0){
        if(D==0){
            printf("이미 카테고리가 존재합니다.\n"); // 이미 카테고리가 존재하는 경우
        }
        else{ // (*tag) (head) 앞에 삽입
            NewTag=CreateTag(NewTagName);
            NewTag->NextTag=(*tag);
            (*tag)=NewTag;
        }
    }
    else{
        Tag* Current=(*tag);

        while(Current->NextTag!=NULL && (D=strcmp( NewTagName, Current->NextTag->TagName))>0)
            Current=Current->NextTag;

        if(D==0){
            printf("이미 카테고리가 존재합니다.\n");
            return; // 이미 카테고리가 존재하는 경우
        }

        else{ // Current 뒤에 삽입
            NewTag=CreateTag(NewTagName);
            NewTag->NextTag=Current->NextTag;
            Current->NextTag=NewTag;
        }
    }
}

void InsertNode(Tag** tag, char* NowTagName, char* NewNodeName){

    Tag* NowTag=SearchTag(*tag, NowTagName);
    Node* CurrentNode;
    int D=-1;

    if(NowTag==NULL){   // 태그가 없는 경우, 태그 생성
        InsertTag(tag, NowTagName);
        NowTag=SearchTag(*tag, NowTagName);
    }

    CurrentNode = NowTag->NextNode; // 태그에 속한 첫번째 노드

    if(CurrentNode==NULL || (D=strcmp( NewNodeName, CurrentNode->NodeName))<=0){ // NewNode가 첫번째 노드보다 사전적으로 앞인 경우,
        if(D==0){
            printf("이미 해당 노드가 존재합니다.\n");
        }
        else{
            Node *NewNode=CreateNode(NewNodeName); // Current(Head) 앞에 삽입
            NewNode->NextNode=CurrentNode;
            NowTag->NextNode=NewNode;
        }
    }
    
    else{
        while(CurrentNode->NextNode!=NULL && (D=strcmp( NewNodeName, CurrentNode->NextNode->NodeName))>0)
            CurrentNode=CurrentNode->NextNode;
        
        if(D==0){
            printf("이미 해당 노드가 존재합니다.\n");
        }
        else{
            Node *NewNode=CreateNode(NewNodeName); // Current 뒤에 삽입
            NewNode->NextNode=CurrentNode->NextNode;
            CurrentNode->NextNode=NewNode;
        }

    }
}

void PrintList(Tag *tag){
    Tag *Nowtag=tag;
    Node *NowNode;

    printf("<현재 노드 상태>\n\n");

    while(Nowtag!=NULL){
    
        NowNode=Nowtag->NextNode;
        printf("%s : ", Nowtag->TagName); // 현재 태그 이름 출력
    
        while(NowNode!=NULL){
            printf("%s", NowNode->NodeName); // 해당 태그에 속한 노드 전부 출력

            if(NowNode->NextNode!=NULL)
                printf("  ->  "); // 노드와 노드 사이 -> 기호 출력

            NowNode=NowNode->NextNode;
        }

        Nowtag=Nowtag->NextTag;
        printf("\n");
    }

    printf("\n-----------------------\n");
}