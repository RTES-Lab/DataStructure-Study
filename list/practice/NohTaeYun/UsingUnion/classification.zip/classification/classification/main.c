#include "classification.h"

int main(void){
    char arr[30]= "Movie";
    Pack2 * Movie = Create(0,arr);
    puts(Movie->Category->Content->Name);
    Pack2 * HarryPotter = Create(1,"Harry Potter");
    Pack2 * TheRing = Create(1,"The Ring");

    Pack2 * Sport = Create(0,"Sport");
    Pack2 * Tennis = Create(1,"Tennis");

    Movie->Category->NextCategory = Sport->Category;
    Movie->Category->Content->NextContent = HarryPotter->Content;
    HarryPotter->Content->NextContent = TheRing->Content;

    Sport->Category->Content->NextContent = Tennis->Content;

    printf("%s\n",Movie->Category->Content->Name);
    printf("%s\n",Movie->Category->Content->NextContent->Name);
    printf("%s\n",HarryPotter->Content->NextContent->Name);
    printf("%s\n",Sport->Category->Content->NextContent->Name);


    Create(0,"Sport");
    Create(1,"Badminton");

    Elementype Line[SizeOfLine] = {};
    fgets(Line,SizeOfLine,stdin); 

    return 0;
}