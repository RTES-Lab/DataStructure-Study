#include "LinkedList.h"

int main(void)
{
    char Array[100];
    char * str = Array;

    int Count = 0;

    Node * List = NULL;
    Node * Current = NULL;
    Node * NewNode = NULL;

    while(1)
    {
        scanf("%s", Array);

        str = strtok(Array, "/");
        int cmd = atoi(str);
        
        switch (cmd)
        {
            case -1:
                return 0;
            case 0:
                //두번째 문자열을 뽑아낸다.
                str = strtok(NULL, "/");
                //존재한다면 에러메세지 출력
                Count = SLL_GetNodeCount(List);

                ///////////////////////////////////////////////////
                if(Count == 0)
                {
                    SSL_AppendNode(&List, SLL_CreateNode(str));
                }

                for(int i = 0 ; i < Count ; i++)
                {
                    Current = SLL_GetNodeAt(List, i);

                    //카테고리가 동일한 게 있다면 - > 오류 메세지 출력
                    if(strcmp(Current->Data, str) == 0)
                    {
                        printf("The Category already exists");
                        break;
                    }

                    //입력받은 카테고리가 기존의 것보다 알파벳이 빠를때
                    if(strcmp(str, Current->Data) > 0)
                    {
                        SLL_InsertAfter(Current-1, SLL_CreateNode(str));
                        Current->type = 0;
                        break;
                    }

                    //입력받은 카테고리가 기존의 것보다 알파벳이 느릴 때
                    if(strcmp(str, Current->Data) < 0)
                    {
                        SLL_InsertAfter(Current, SLL_CreateNode(str));
                        Current->type = 0;
                        break;
                    }
                }
                
                //while로 다시 돌아가기
                continue;
                
                
            //이 경우, 2번째 /부터, '\0'을 만날 때까지 분할
            case 1:
                // 해당 str은 속해있는 카테고리 문자열이 됨
                str = strtok(NULL, "/");

                Count = SLL_GetNodeCount(List);

                if(Count == 0)
                {
                    SSL_AppendNode(&List, SLL_CreateNode(str));
                    List->type = 0;

                    str = strtok(NULL, '\0');
                    SLL_InsertAfter(List, SLL_CreateNode(str));
                    (List+1)->type = 1;
                }
                
                for(int i = 0 ; i < Count ; i++)
                {
                    Current = SLL_GetNodeAt(List, i);

                    //카테고리가 동일한게 있고
                    if(strcmp(str, Current->Data) ==0 && Current->type == 0)
                    {
                        int j = 1;
                        while((Current+j)->type != 0)
                        {
                            // 2번째 /부터, '\0'을 만날 때까지 분할
                            str = strtok(NULL, '\0');

                            // 항목 동일 - > 오류 메세지 출력
                            if(strcmp(str, (Current+j)->Data) == 0)
                            {
                                printf("The item already exists");
                                break;
                            }

                            // 항목 동일 없어서 - > str이 작으면
                            if(strcmp(str, (Current+j)->Data) > 0)
                            {
                                SLL_InsertAfter(Current+j-1, SLL_CreateNode(str));
                                Current->type = 1;
                                break;
                            }

                            // 항목 동일 없어서 - > str이 크면
                            if(strcmp(str, (Current+j)->Data) < 0)
                            {
                                SLL_InsertAfter(Current+j, SLL_CreateNode(str));
                                Current->type = 1;
                                break;
                            }
                            j++;

                        }
                    }
                    
                }

                continue;

            //출력 - > Count 변수를 통해 처음부터 순차적으로 접근
            case 2:
                //한 칸 띄고
                printf("\n");

                //1) 노드 중에 Type이 0인(카테고리인)거 :붙여서 출력하고
                Count = SLL_GetNodeCount(List);
                if(Count == 0)
                {
                    break;
                }

                for(int i = 0 ; i < Count ; i++)
                {
                    Current = SLL_GetNodeAt(List, i);

                    //카테고리라면
                    if(Current->type == 0)
                    {
                        printf("%s: ", Current->Data);
                    }

                    //항목이라면
                    if(Current->type == 1)
                    {
                        //다음게 항목이라면
                        if((Current+1)->type == 1)
                        {
                            printf("%s  ->  ", Current->Data);
                        }

                        //다음게 카테고리라면
                        if((Current+1)->type == 0)
                        {
                            printf("%s\n", Current->Data);
                        }
                        
                    }
                }
                break;

            default:
                printf("This is the Command we don't allow");
        }
        //바깥 무한루프 탈출
        break;
    }
}